// Select the play button and redirect to game.html
